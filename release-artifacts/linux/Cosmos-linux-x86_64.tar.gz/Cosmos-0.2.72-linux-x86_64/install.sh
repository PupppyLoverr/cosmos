#!/usr/bin/env bash
# Install Cosmos into ~/.local (no root needed).
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
install -Dm755 "$HERE/cosmos" "$HOME/.local/bin/cosmos"
install -Dm644 "$HERE/cosmos.png" "$HOME/.local/share/icons/hicolor/512x512/apps/cosmos.png"
sed "s|^Exec=.*|Exec=$HOME/.local/bin/cosmos %u|; s|^TryExec=.*|TryExec=$HOME/.local/bin/cosmos|" \
  "$HERE/cosmos.desktop" > "$HOME/.local/share/applications/cosmos.desktop"
command -v update-desktop-database >/dev/null 2>&1 \
  && update-desktop-database "$HOME/.local/share/applications" || true
echo "Installed Cosmos to ~/.local/bin/cosmos — ensure ~/.local/bin is on PATH."
