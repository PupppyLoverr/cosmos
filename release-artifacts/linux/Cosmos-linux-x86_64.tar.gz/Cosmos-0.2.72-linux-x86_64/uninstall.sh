#!/usr/bin/env bash
set -euo pipefail
rm -f "$HOME/.local/bin/cosmos" \
      "$HOME/.local/share/icons/hicolor/512x512/apps/cosmos.png" \
      "$HOME/.local/share/applications/cosmos.desktop"
echo "Removed Cosmos from ~/.local."
